import FileViewPageContent from '../components/FileStorage/FileViewPageContent';


const FileViewPage = () => {
  return <FileViewPageContent />;
};

export default FileViewPage;
