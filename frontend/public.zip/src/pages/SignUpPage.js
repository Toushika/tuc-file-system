import React from 'react';
import SignUpForm from '../components/Auth/SignUpForm';

function SignUpPage() {
  return (
      <SignUpForm />
  )
}

export default SignUpPage
