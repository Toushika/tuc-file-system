import ViewOwnFiles from '../components/FileStorage/ViewOwnFiles';

const ViewOwnFilePage = () => {
  return <ViewOwnFiles />;
};

export default ViewOwnFilePage;
