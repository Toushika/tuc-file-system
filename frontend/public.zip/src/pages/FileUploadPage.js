import FileUploadPageContent from '../components/FileStorage/FileUploadPageContent';

const FileUploadPage = () => {
  return <FileUploadPageContent />;
};

export default FileUploadPage;
