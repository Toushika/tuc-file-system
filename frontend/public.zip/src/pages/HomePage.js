

import FileViewPageContentWithPagination from '../components/FileStorage/FileViewPageContentWithPagination'
const HomePage = () => {
  return (
    <FileViewPageContentWithPagination />
  );
};

export default HomePage;
