import React from 'react'
import ViewRequestByUserContent from '../components/FileStorage/ViewRequestByUserContent';

const ViewRequestByUserPage= ()=> {
  return (
    <ViewRequestByUserContent/>
  )
}

export default ViewRequestByUserPage;